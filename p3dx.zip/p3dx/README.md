ua_ros_p3dx
===========

A ROS/Gazebo Pioneer 3DX model.

To install:
```
$ cd <catking_workspace_directory>/src
$ git clone URL # (see github)
$ cd ..
$ catkin_make
```
